<?php include("header.php") ?>
<!-- fEatured pRoduct Area -->
<div class="inner-page">
	<div class="container-fluid">
		<div class="row">	
			<div class="inner-banner">
					<img src="images/inner-banner.jpg" class="img-responsive"/>
			</div>
			<div class="inner-page-content">
				<div class="col-md-12">
				<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Wireless Accessories</span></h4>
				</div>
				<div class="sub-cateogy col-md-12">
					
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/wireless-earphone/wireless16.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Maganet Earphone  WB-H14</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/wireless-earphone/wireless17.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Maganet Earphone  WB-H14</h3>
							</div>
						</div>
					</div>
					
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/wireless-earphone/wireless19.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Maganet Earphone  WB-H14</h3>
							</div>
						</div>
					</div>
					
					
					
			
					

					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/wireless-earphone/wireless1.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Wireless Earphone</h3>
							</div>
						</div>
					</div>
					
				
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/wireless-earphone/wireless4.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Wireless Earphone</h3>
							</div>
						</div>
					</div>
					
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.6s">
								<img src="images/wireless-earphone/wireless6.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Wireless Earphone</h3>
							</div>
						</div>
					</div>	
				
					
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/wireless-earphone/wireless7.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>Wireless Earphone CV-B4</h3>
								</div>
							</div>
						</div>
					
					
					
					
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
									<img src="images/wireless-earphone/wireless11.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>Wireless Headphone BH-48</h3>
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.6s">
									<img src="images/wireless-earphone/wireless12.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>Wireless Headphone BH-48</h3>
								</div>
							</div>
						</div>	
					
					
							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
										<img src="images/wireless-earphone/wireless14.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone CG-H15</h3>
									</div>
								</div>
							</div>
							
				
						
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless24.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Maganet Earphone WB-B11</h3>
									</div>
								</div>
							</div>

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless25.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Maganet Earphone WB-B11</h3>
									</div>
								</div>
							</div>
					
							

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless27.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone</h3>
									</div>
								</div>
							</div>

						
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
										<img src="images/wireless-earphone/wireless29.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone</h3>
									</div>
								</div>
							</div>
						
							
							
					

							
						

							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
										<img src="images/wireless-earphone/wireless36.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-15</h3>
									</div>
								</div>
							</div>
							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless38.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-15</h3>
									</div>
								</div>
							</div>

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless39.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-15</h3>
									</div>
								</div>
							</div>

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless40.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-15</h3>
									</div>
								</div>
							</div>

							
							
					
							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless43.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-H13</h3>
									</div>
								</div>
							</div>

							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
										<img src="images/wireless-earphone/wireless45.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-H13</h3>
									</div>
								</div>
							</div>
						

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless47.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headphone WB-H13</h3>
									</div>
								</div>
							</div>

						
							

							
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless50.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headset CV-B41</h3>
									</div>
								</div>
							</div>

			
						
							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless54.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headset WB-042</h3>
									</div>
								</div>
							</div>

							<div class="col-sm-3 col-md-3">
								<div class="accessories-body">
									<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
										<img src="images/wireless-earphone/wireless55.png" class="img-responsive" alt="" />
									</div>
									<div class="accessories-footer">
										<h3>Wireless Headset WB-042</h3>
									</div>
								</div>
							</div>
							
						

					</div>
				</div>
				</div>				
			</div>
		</div>
							</div>
							
						</div>
								
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>