<?php include("header.php") ?>
	 <!-- Start Slider Area -->
	 <div class="">
  <div id="home" class="slider-area">
    <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides">
        <img src="images/slider/slider1.jpg" alt="" title="#slider-direction-1" />
        <img src="images/slider/slider2.jpg" alt="" title="#slider-direction-2" />
        <img src="images/slider/slider3.jpg" alt="" title="#slider-direction-3" />
      </div>
    </div>
  </div>
</div>
  <!-- End Slider Area -->
	<!-- bAnner Area-->
		<!-- <div class="banner">
			<div class="container-fluid">
				<div class="row">		
				<img src="images/banner.jpg" class="img-responsive" />			
				</div>				
			</div>
		</div> -->
		
	<!--eNd bAnner Area-->

	<!-- aBout uS Area-->		
			<section id="about">
	            <div class="container">
	                <div class="row">

	                    <div class="col-md-9">
	                        <div class="about_content">
	                            <img src="images/about_img.jpg" alt="" class="about_img" />
	                            <h2>Welcome To CROVELL</h2>

	                            <p>The Mumbai-based Crovell, a new brand of mobile accessories is all set to be launched in November 2019 with a range of innovative and latest products. 
Mobile phones have become no less than a body part to us and it is important that they look like the extension of our personality. Dress them up in your favorite colors, patterns, and styles or let them display your favorite quotations and sayings. At Crovell.in Pick out the best mobile phone covers. Look out for the best and latest mobile accessories online in India. 
</p>

	                            <a href="about.php" class="btn know_btn">Know More</a>
	                        </div>
	                    </div>
	                    <div class="col-md-3">
	                        <div class="yoga_content">
	                            <div class="yoga">
	                                <h3>Love Music <span>&xlarr;</span></h3>
	                                <p>Music is a love of life Headphone,Earphone etc.</p>

	                               <!--  <a href="" class="btn link_btn">Know More</a> -->
	                            </div>
	                            <div class="yoga_banner">
	                                <img src="images/yoga_img.jpg" alt="Yoga" class="yoga_img" />
	                                <div class="photo_overlay"></div>
	                            </div>					
	                        </div>
	                    </div>

	                </div>
	            </div>
	        </section>
	<!--eNd aBout uS Area-->

	

		<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Mobile</span> Accessories</h4>
				</div>
				
				<div class="col-sm-6 col-md-3">
					<a href="speakar.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInDown" data-wow-delay="0.8s" >
								<img src="images/speakar/speakar-4.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>SPEAKER</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="headset.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInUp" data-wow-delay="0.8s">
								<img src="images/headset/headset13.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>HEADPHONE</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="charger.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInDown" data-wow-delay="0.8s">
								<img src="images/car-charger/car-charger6.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>CHARGER</h3>
							</div>
						</div>
					</a>
				</div>	
				
				<div class="col-sm-6 col-md-3">
					<a href="wireless-earphone.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInUp" data-wow-delay="0.8s">
								<img src="images/wireless-earphone/wireless12.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>EARPHONES</h3>
							</div>
						</div>
					</a>
				</div>
				

				</div>				
			</div>
		</div>
		   <!-- Coaches -->
        <div id="coaches" class="coaches">
            <div class="container">
            	<div class="col-md-12">	
					<h4><span>Our</span> Products</h4>
				</div>
                <div class="coaches_content">
                    <div class="size_180 wow tada coach_item" data-wow-delay="0.8s">
                    	<img src="images/coach_img10.png" alt="" />
                       
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="0.2s">
                        <img src="images/coach_img1.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1.4s">
                        <img src="images/coach_img9.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="0.8s">
                        <img src="images/coach_img3.png" alt="" />
                    </div>
                    <div class="size_180 wow tada coach_item" data-wow-delay="0.8s">
                    	<img src="images/coach_img11.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="0.6s">
                        <img src="images/coach_img4.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1s">
                        <img src="images/coach_img5.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1.2s">
                        <img src="images/coach_img6.png" alt="" />
                    </div>
                     <div class="size_180 wow tada coach_item" data-wow-delay="0.8s">
                    	<img src="images/coach_img13.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1.4s">
                       	<img src="images/coach_img12.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1.6s">
                        <img src="images/coach_img8.png" alt="" />
                    </div>
                    <div class="size_180 coach_item wow bounceIn" data-wow-delay="1.8s">
                        <img src="images/coach_img1.png" alt="" />
                    </div>
                    <div class="size_180 coach_item">
                        <img src="images/coach_img7.png" alt="" />
                    </div>			
                </div>
            </div>
        </div><!-- Coaches end -->
	<!--eNd cRovell pRoduct Area-->		

	<!-- fEatured pRoduct Area -->
		<div class="">
			<div class="container-fluid">
				<div class="row">					
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	<!-- gAllery Area -->
		<div class="gallery-section">
			<div class="container">
				<div class="">
				<div class="col-md-12">	
					<h4><span>Our</span> Gallery</h4>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="gallery-panel">
						<div class="gallery-img">
					 		<img src="images/pic01.jpg" class="img-responsive wow bounceInLeft" data-wow-delay="0.4s" alt="Coach" />
					 	</div>
					 	<div class="gallery-img">
					 		<img src="images/pic02.jpg" class="img-responsive wow bounceInUp" data-wow-delay="2.2s" alt="Coach" />
					 	</div>
					</div>
				</div>	
				<div class="col-sm-3 col-md-3">
					<div class="gallery-panel">
						<div class="gallery-img">
					 		<img src="images/pic04.jpg" class="img-responsive wow bounceIn" data-wow-delay="2.6s" alt="Coach" />
					 	</div>
					 	<div class="gallery-img">
					 		<img src="images/pic03.jpg" class="img-responsive wow bounceIn" data-wow-delay="0.8s" alt="Coach" />
					 	</div>
					</div>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="gallery-panel">
						<div class="gallery-img">
					 		<img src="images/pic05.jpg" class="img-responsive wow bounceIn" data-wow-delay="1.2s" alt="Coach" />
					 	</div>
					 	<div class="gallery-img">
					 		<img src="images/pic06.jpg" class="img-responsive wow bounceIn" data-wow-delay="3s" alt="Coach" />
					 	</div>
					</div>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="gallery-panel">
						<div class="gallery-img">
					 		<img src="images/pic08.jpg" class="img-responsive wow bounceInDown" data-wow-delay="3.4s" alt="Coach" />
					 	</div>
					 	<div class="gallery-img">
					 		<img src="images/pic07.jpg" class="img-responsive wow bounceInRight" data-wow-delay="1.6s" alt="Coach" />
					 	</div>
					</div>
				</div>

				</div>				
			</div>
		</div>
	<!--eNd gAllery Area -->

	<?php include("footer.php"); ?>