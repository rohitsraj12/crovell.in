<?php include("header.php") ?>
	
 


	<!-- fEatured pRoduct Area -->
		<div class="inner-page">
			<div class="container-fluid">
				<div class="row">	
					<div class="inner-banner">
						<img src="images/inner-banner.jpg" class="img-responsive"/>
					</div>
					<div class="inner-page-content">
					
							<div class="col-md-12">
								<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Speaker</span></h4>
				</div>
				<div class="sub-cateogy col-md-12">
				
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/speakar/speakar-11.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Bluetooth speaker CV 111</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/speakar/speakar-2.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Bluetooth speaker CV 112</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/speakar/speakar-4.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Bluetooth Speaker CV 113</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/speakar/speakar-8.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Bluetooth Speaker CV 114</h3>
							</div>
						</div>
					</div>

					<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/speakar/speakar-14.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>Wireless Speaker Cl-887</h3>
								</div>
							</div>
						</div>

					<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/speakar/speakar-17.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>Wireless Speaker CV-889</h3>
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/speakar/speakar-29.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>MP3 Player CV -04</h3>
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/speakar/speakar-22.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>MP3 Big Display CV-06</h3>
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/speakar/speakar-26.png" class="img-responsive" alt="" />
								</div>
								<div class="accessories-footer">
									<h3>MP3 Big Display CV-06</h3>
								</div>
							</div>
						</div>			
				</div>				
			</div>
		</div>
							</div>
							
						</div>
								
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>