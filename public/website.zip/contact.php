<?php include("header.php") ?>
	
 


	<!-- fEatured pRoduct Area -->
		<div class="inner-page">
			<div class="container-fluid">
				<div class="row">	
					<div class="inner-banner">
						<img src="images/inner-banner.jpg" class="img-responsive"/>
					</div>
					<div class="inner-page-content">
						<div class="container">
							<div class="row">
								<div class="col-md-12">
	                            <div class="form-group">
	                                <?php if($responseArray == 1){ ?>
	                                <div class=""  id="sucmailmsgdiv1"  style="height: 34px;padding: 4px 13px; color:#aace44" >Thank you for contacting us.  We will be in touch shortly.</div>
	                                <?php } else if($responseArray == 2){?>
	                                <div class="msg-alert alert-danger"  id="sucmailmsgdiv1"  style="height: 34px;padding: 4px 13px;" >Error while sending mail</div>
	                                
	                                <?php } ?>
	                              </div>
	                            </div>
							</div>	
							<div class="row">
								<div class="col-md-5 pd-rgt">
									<div class="contact-info wow fadeInLeft" data-wow-delay="0.8s">
										<h4>Address</h4>
										<h5>Crovell Impex</h5>
										<p>Orchid City Center,<br> Shop No. C2-573 & C2-574,  <br>2nd Floor, Opp. BEST Bus Depot,<br>
								Bellasis Road, Mumbai Central(E), <br>Mumbai – 400 008.</p>

										<h5>Contact Number</h5>	
										<ul>
											<li>Phone : +91 9867509840</li>
											<li>Phone : +91 9869935710</li>
											<li>Telephone : 022-6188 6573</li>
											
											<li><a href="mailto:info@example.com">info@crovell.in</a></li>
										</ul>
										<div class="clearfix"></div>
										<div class="contactsocialicon">
											<h5>Social Media</h5>
											<div class="socil-mdia-link">
												<a href="https://www.facebook.com/Crovell-Mobile-Accessories-1190409514467758/?modal=admin_todo_tour" title="" target="blank"><img src="images/facebook.png" class="social-ftr-icn" alt="" /></a>
												<a href="https://www.instagram.com/crovellpage/" title="" target="blank"><img src="images/instagram.png" alt="" /></a>
												<a href="https://twitter.com/Crovell1" title="" target="blank"><img src="images/twitter.png" alt="" /></a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-7 pd-lft">
									<div class="contact-form wow fadeInRight " data-wow-delay="0.8s">
										<h4>Contact With Us</h4>
										<form method="post" id="contactForm">
											<div class="row">
											<div class="col-md-4">
												<input type="text" name="fname"  placeholder="Your Name">
											</div>
											<div class="col-md-4">
												<input type="email"  name="email" placeholder="Your Email" >
											</div>
											<div class="col-md-4">
												<input type="text"  name="mobile" placeholder="Telephone No" r>
											</div>
											<div class="col-md-12">
												<textarea name="message"  placeholder="Message..." ></textarea>
											</div>
											<input type="submit" name="btn-cnt-submit" class="btn know_btn" value="Submit" >
										</div>
										</form>
									</div>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>					
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>