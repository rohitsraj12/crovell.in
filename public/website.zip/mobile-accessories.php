<?php include("header.php") ?>
	<!-- fEatured pRoduct Area -->
		<div class="inner-page">
			<div class="container-fluid">
				<div class="row">	
					<div class="inner-banner">
						<img src="images/inner-banner.jpg" class="img-responsive"/>
					</div>
					<div class="inner-page-content">
					
							<div class="col-md-12">
								<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Mobile</span> Accessories</h4>
				</div>
				
				<div class="col-sm-6 col-md-3">
					<a href="speakar.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInDown" data-wow-delay="0.8s" >
								<img src="images/speakar/speakar-4.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>SPEAKER</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="headset.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInUp" data-wow-delay="0.8s">
								<img src="images/headset/headset13.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>HEADPHONE</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="charger.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInDown" data-wow-delay="0.8s">
								<img src="images/car-charger/car-charger6.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>CAR CHARGER</h3>
							</div>
						</div>
					</a>
				</div>	
				
				<div class="col-sm-6 col-md-3">
					<a href="wireless-earphone.php">
						<div class="accessories-body">
							<div class="accessories-panel wow bounceInUp" data-wow-delay="0.8s">
								<img src="images/wireless-earphone/wireless12.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>EARPHONES</h3>
							</div>
						</div>
					</a>
				</div>
				
				<div class="col-sm-6 col-md-3">
					<a href="cable.php">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInRight" data-wow-delay="0.4s">
								<img src="images/cable.jpg" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>CABLE</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="power-bank.php">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInRight" data-wow-delay="0.6s">
								<img src="images/powerbank.jpg" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>POWER BANK</h3>
							</div>
						</div>
					</a>
				</div>	
				
				<div class="col-sm-6 col-md-3">
					<a href="charger.php">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInRight" data-wow-delay="0.8s">
								<img src="images/charger.jpg" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>CHARGER</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-sm-6 col-md-3">
					<a href="other.php">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInRight" data-wow-delay="0.2s" >
								<img src="images/other.jpg" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>OTHER</h3>
							</div>
						</div>
					</a>
				</div>
				</div>				
			</div>
		</div>
							</div>
							
						</div>
								
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>