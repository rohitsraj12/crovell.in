<?php include("header.php") ?>
	
 


	<!-- fEatured pRoduct Area -->
		<div class="inner-page">
			<div class="container-fluid">
				<div class="row">	
					<div class="inner-banner">
						<img src="images/inner-banner.jpg" class="img-responsive"/>
					</div>
					<div class="inner-page-content">
					
							<div class="col-md-12">
								<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Speaker</span></h4>
				</div>
				<div class="sub-cateogy col-md-12">
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/client-img-charger/1.png" class="img-responsive" alt="" />
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/client-img-charger/2.png" class="img-responsive" alt="" />
							</div>
							
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/client-img-charger/3.png" class="img-responsive" alt="" />
							</div>
													</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/client-img-charger/4.png" class="img-responsive" alt="" />
							</div>
							
						</div>
					</div>

					<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/client-img-charger/5.png" class="img-responsive" alt="" />
								</div>
								
							</div>
						</div>

					<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/client-img-charger/6.png" class="img-responsive" alt="" />
								</div>
								
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/client-img-charger/7.png" class="img-responsive" alt="" />
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/client-img-charger/8.png" class="img-responsive" alt="" />
								</div>
							</div>
						</div>
						<div class="col-sm-3 col-md-3">
							<div class="accessories-body">
								<div class="wow fadeInLeft" data-wow-delay="0.2s" >
									<img src="images/client-img-charger/9.png" class="img-responsive" alt="" />
								</div>
							</div>
						</div>			
				</div>				
			</div>
		</div>
							</div>
							
						</div>
								
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>