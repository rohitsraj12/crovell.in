<?php include("header.php") ?>
	
 


	<!-- fEatured pRoduct Area -->
		<div class="inner-page">
			<div class="container-fluid">
				<div class="row">	
					<div class="inner-banner">
						<img src="images/inner-banner.jpg" class="img-responsive"/>
					</div>
					<div class="inner-page-content">
					
							<div class="col-md-12">
								<!-- cRovell pRoduct aRea-->
		<div class="accessories-section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">	
					<h4><span>Power Bank</span></h4>
				</div>
				<div class="col-md-12">
					

					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/power-bank/powerbank1.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank C.P-53</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/power-bank/powerbank2.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank C.P-53</h3>
							</div>
						</div>
					</div>

					
										
					
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/power-bank/powerbank5.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank 5V 1V</h3>
							</div>
						</div>
					</div>
					

					
					
						
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/power-bank/powerbank7.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank 5V 1V</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/power-bank/powerbank8.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank 5V 1V</h3>
							</div>
						</div>
					</div>
					
				
					
				
						
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/power-bank/powerbank10.png" class="img-responsive" alt="" />
							</div>
								<div class="accessories-footer">
								<h3>Power Bank C.P-52</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/power-bank/powerbank11.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank C.P-52</h3>
							</div>
						</div>
					</div>
					
				
				
						
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.2s" >
								<img src="images/power-bank/powerbank13.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank C.P-54</h3>
							</div>
						</div>
					</div>
					<div class="col-sm-3 col-md-3">
						<div class="accessories-body">
							<div class="accessories-panel wow fadeInLeft" data-wow-delay="0.4s">
								<img src="images/power-bank/powerbank14.png" class="img-responsive" alt="" />
							</div>
							<div class="accessories-footer">
								<h3>Power Bank C.P-54</h3>
							</div>
						</div>
					</div>
					
					

					</div>
				</div>

			

				</div>				
			</div>
		</div>
							</div>
							
						</div>
								
				</div>				
			</div>
		</div>
	<!--eNd fEatured pRoduct Area -->

	
	<?php include("footer.php"); ?>